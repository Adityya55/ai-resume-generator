import openai

openai.api_key = "your-api-key"
def generate_resume_text(data):
    prompt = f"""
    Create a professional resume using the following details:
    Name: {data.name}
    Education: {data.education}
    Skills: {data.skills}
    Projects: {data.projects}
    Format it properly with headers like Summary, Education, Skills, Projects.
    """
    
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # or gpt-4 if available
        messages=[{"role": "user", "content": prompt}],
        max_tokens=800,
        temperature=0.7
    )

    return response['choices'][0]['message']['content']
